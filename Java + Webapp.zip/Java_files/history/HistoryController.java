/**
 * 
 */
package org.bgu.ise.ddb.history;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.ParentController;
import org.bgu.ise.ddb.User;
import org.bgu.ise.ddb.items.ItemsController;
import org.bgu.ise.ddb.registration.RegistarationController;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/history")
public class HistoryController extends ParentController{
	
	
	
	/**
	 * The function inserts to the system storage triple(s)(username, title, timestamp). 
	 * The timestamp - in ms since 1970
	 * Advice: better to insert the history into two structures( tables) in order to extract it fast one with the key - username, another with the key - title
	 * @param username
	 * @param title
	 * @param response
	 */
	@RequestMapping(value = "insert_to_history", method={RequestMethod.GET})
	public void insertToHistory (@RequestParam("username")    String username,
			@RequestParam("title")   String title,
			HttpServletResponse response){
		System.out.println(username+" "+title);
		//:TODO your implementation

		//Initialise variables
		HttpStatus status = null;
		MongoClient mongoClient = null;
		RegistarationController regist_control = null;
		ItemsController item_control = null;

		try {
			// Create a connection and get the History collections
			mongoClient = new MongoClient("localhost", 27017);
			// Get the MongoDB database
            DB db = mongoClient.getDB("BigDataProject");
            // Get the collection that holds the items
            DBCollection collection = db.getCollection("viewHistory");
         // Get the collection that holds the items
            DBCollection coll_item = db.getCollection("Items");
            // Create a query to check if the item exists by title
            BasicDBObject query = new BasicDBObject("title", title);
            // Execute the query and check if any document matches the query
            boolean exists = coll_item.count(query) > 0;
            
            //Creating an instance of the RegistarationController class
			regist_control = new RegistarationController();


            //check if the user exists in the system storage and whether any document matches the 
			//query for the given title in the viewHistory collection.
			if (regist_control.isExistUser(username) && exists) {

				// Create new document of this view and insert it to the collection
				DBObject doc = new BasicDBObject();
				doc.put("username", username);
				doc.put("title", title);
				doc.put("timestamp", new Date().getTime());
				collection.insert(doc);

				// Update status after creating the record
				status = HttpStatus.OK;
				
			} else {
				System.out.println("Username or movie were not found in the system storage");
				status = HttpStatus.CONFLICT;
			}

		} catch (Exception e) {
			e.printStackTrace();
			status = HttpStatus.CONFLICT;
		} finally {
			if (mongoClient != null)
				mongoClient.close();
			response.setStatus(status.value());
		}
	
	}
	
	
	
	/**
	 * The function retrieves  users' history
	 * The function return array of pairs <title,viewtime> sorted by VIEWTIME in descending order
	 * @param username
	 * @return
	 */
	@RequestMapping(value = "get_history_by_users",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(HistoryPair.class)
	public  HistoryPair[] getHistoryByUser(@RequestParam("entity")    String username){
		//:TODO your implementation
//		HistoryPair hp = new HistoryPair("aa", new Date());
//		System.out.println("ByUser "+hp);
//		return new HistoryPair[]{hp};
		
		
		// Initialise variables array - to store the history pairs
		ArrayList<HistoryPair> historyPairs = new ArrayList<HistoryPair>();
		MongoClient mongoClient = null;

		try {

			// Create a connection and get the History collection
			mongoClient = new MongoClient("localhost", 27017);
			// Get the MongoDB database
            DB db = mongoClient.getDB("BigDataProject");
            // Get the collection that holds the items
            DBCollection coll_history = db.getCollection("viewHistory");

            //Creating an instance of the RegistarationController class 
			RegistarationController regist_control = new RegistarationController();
			
			//Check if the user with the given username exists in Mongo DB
			if (!regist_control.isExistUser(username)) {
				//If the user does not exist, a message is printed
				System.out.println("No user with this username was found in the system storage");
				return null;
			}

			// The query filters the documents based on the "username" field matching the given username.
			//The results are sorted in descending order based on the "timestamp" field
			DBCursor cursor = coll_history.find(new BasicDBObject("username", username))
	                .sort(new BasicDBObject("timestamp", -1));

			
			try {
				//iterate over the documents
				while (cursor.hasNext()) {
					//Retrieve the next document
				    DBObject document = cursor.next();
				    //Retrieve the value of the "title" field from the document
				    String title1 = document.get("title").toString();
				    //Retrieve the value of the "timestamp" field from the document
				    Date timestamp = new Date(((Number) document.get("timestamp")).longValue());
				    //Add the pair to the array 
				    historyPairs.add(new HistoryPair(title1, timestamp));
				}

			} finally {
				cursor.close();
			}
			} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (mongoClient != null)
						mongoClient.close();
				}

				if (historyPairs.size() == 0)
					System.out.println("No view history was found for this movie");

				return historyPairs.toArray(new HistoryPair[historyPairs.size()]);
			
	}
	
	
	/**
	 * The function retrieves  items' history
	 * The function return array of pairs <username,viewtime> sorted by VIEWTIME in descending order
	 * @param title
	 * @return
	 */
	@RequestMapping(value = "get_history_by_items",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(HistoryPair.class)
	public  HistoryPair[] getHistoryByItems(@RequestParam("entity")    String title){
		//:TODO your implementation
//		HistoryPair hp = new HistoryPair("aa", new Date());
//		System.out.println("ByItem "+hp);
//		return new HistoryPair[]{hp};
	
		
		// Initialise variables array - to store the history pairs
		ArrayList<HistoryPair> historyPairs = new ArrayList<HistoryPair>();
		MongoClient mongoClient = null;

		try {

			// Create a connection and get the History collection
			mongoClient = new MongoClient("localhost", 27017);
			// Get the MongoDB database
            DB db = mongoClient.getDB("BigDataProject");
            // Get the collection that holds the history view
            DBCollection coll_history = db.getCollection("viewHistory");
            // Get the collection that holds the items
			DBCollection coll_item = db.getCollection("Items");

            //Creating an instance of the RegistarationController class 
			RegistarationController regist_control = new RegistarationController();
			
			
             // Create a query to check if the item exists by title
             BasicDBObject query = new BasicDBObject("title", title);
             // Execute the query and check if any document matches the query
             boolean exists = coll_item.count(query) > 0;

             
             //Check if the item doesn't exist in Mongo DB  
             if (!exists) {
				//If the user does not exist, a message is printed
				System.out.println("No movie with this title was found in the system storage");
				return null;
			}

			// The query filters the documents based on the "title" field matching the given title.
			//The results are sorted in descending order based on the "timestamp" field
			DBCursor cursor = coll_history.find(new BasicDBObject("title", title))
	                .sort(new BasicDBObject("timestamp", -1));

			
			try {
				//iterate over the documents
				while (cursor.hasNext()) {
					//Retrieve the next document
				    DBObject document = cursor.next();
				    //Retrieve the value of the "title" field from the document
				    String user = document.get("username").toString();
				    //Retrieve the value of the "timestamp" field from the document
				    Date timestamp = new Date(((Number) document.get("timestamp")).longValue());
				    //Add the pair to the array 
				    historyPairs.add(new HistoryPair(user, timestamp));
				}

			} finally {
				cursor.close();
			}
			} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (mongoClient != null)
						mongoClient.close();
				}

				if (historyPairs.size() == 0)
					System.out.println("No view history was found for this username");

				return historyPairs.toArray(new HistoryPair[historyPairs.size()]);
			
	}
	
	
	/**
	 * The function retrieves all the  users that have viewed the given item
	 * @param title
	 * @return
	 */
	@RequestMapping(value = "get_users_by_item",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(HistoryPair.class)
	public  User[] getUsersByItem(@RequestParam("title") String title){
		//:TODO your implementation
//		User hp = new User("aa","aa","aa");
//		System.out.println(hp);
//		return new User[]{hp};
		
		 // Initialise variables
	    RegistarationController regist_control = new RegistarationController();
	    ArrayList<User> users_array = new ArrayList<User>();
	    MongoClient mongoClient = null;
	    ItemsController item_control = new ItemsController();
	    
	    
	    try {    
		// Create a connection and get the History collection
		mongoClient = new MongoClient("localhost", 27017);
		// Get the MongoDB database
        DB db = mongoClient.getDB("BigDataProject");
        // Get the collection that holds the users
        DBCollection coll_users = db.getCollection("Users");
        // Get the collection that holds the history view
        DBCollection coll_history = db.getCollection("viewHistory");
        // Get the collection that holds the items
		DBCollection coll_item = db.getCollection("Items");
        // Create a query to check if the item exists by title
        BasicDBObject query = new BasicDBObject("title", title);
        // Execute the query and check if any document matches the query
        boolean exists = coll_item.count(query) > 0;

         
        //Check if the item doesn't exist in Mongo DB  
        if (!exists) {
	        System.out.println("No movie with this title was found in the system storage");
	        return null;
	    }
        
        //Get the pairs from the previous function for the specific title
	    HistoryPair[] viewHistory = getHistoryByItems(title);
	    
	    //create an empty array
	    ArrayList<String> usernames = new ArrayList<String>();
	    //Add the usernames to the array according to the given title
	    for (HistoryPair view : viewHistory) {
	        usernames.add(view.getCredentials());
	    }


	        //Find documents where the value of the 'username' field matches any value in the usernames list
	    	//We need to find this document in order to find the details of the user
	        BasicDBObject query1 = new BasicDBObject("username", new BasicDBObject("$in", usernames));
	        // Execute the query and get the cursor
	        DBCursor cursor = coll_users.find(query1);

	        // Map documents within the collection to Users objects
	        try {
	        	//As long as there are more documents
	            while (cursor.hasNext()) {
	            	//Retrieve the next document
	                DBObject document = cursor.next();
	                // Create new user document and insert it to the DB
	                String username = (String) document.get("username");
	                String firstName = (String) document.get("firstName");
	                String lastName = (String) document.get("lastName");
	                String password = (String) document.get("password");
					
	                //Create new object of user
				    User user;
				    user = new User(username, password, firstName, lastName);
				    //Add the new user to the users array
	                users_array.add(user);
	            }
	        } finally {
	            cursor.close();
	        }

	    } catch (Exception e) {
	        e.printStackTrace();

	    } finally {
	        if (mongoClient != null)
	            mongoClient.close();
	    }

	    System.out.println(users_array);
	    return users_array.toArray(new User[users_array.size()]);
	}
	
	/**
	 * The function calculates the similarity score using Jaccard similarity function:
	 *  sim(i,j) = |U(i) intersection U(j)|/|U(i) union U(j)|,
	 *  where U(i) is the set of usernames which exist in the history of the item i.
	 * @param title1
	 * @param title2
	 * @return
	 */
	@RequestMapping(value = "get_items_similarity",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	public double  getItemsSimilarity(@RequestParam("title1") String title1,
			@RequestParam("title2") String title2){
		//:TODO your implementation
		
		//Initialise variables
		MongoClient mongoClient = null;
	    double result = 0.0;

		
	    try {    
			// Create a connection and get the History collection
			mongoClient = new MongoClient("localhost", 27017);
			// Get the MongoDB database
	        DB db = mongoClient.getDB("BigDataProject");
	        // Get the collection that holds the users
	        DBCollection coll_users = db.getCollection("Users");
	        // Get the collection that holds the history view
	        DBCollection coll_history = db.getCollection("viewHistory");
	        // Get the collection that holds the items
			DBCollection coll_item = db.getCollection("Items");
	        // Create a query to check if the item exists by title1
	        BasicDBObject query1 = new BasicDBObject("title", title1);
	        // Create a query to check if the item exists by title2
	        BasicDBObject query2 = new BasicDBObject("title", title2);
	        // Execute the queries and check if any document matches the queries
	        boolean exists1 = coll_item.count(query1) > 0;
	        boolean exists2 = coll_item.count(query2) > 0;
		         
		    //Check if the items doesn't exist in Mongo DB  
			if (!(exists1 && exists2)){
				System.out.println("At least one of the movies wasn't found in the system storage");
				return 0;
			}
			
			
		    //array to store usernames related to title1
			ArrayList<String> first_item = new ArrayList<String>();
			for (User u : getUsersByItem(title1)) {
				//add their username to the first item array
				first_item.add(u.getUsername());
			}
			
		    //array to store usernames related to title2
			ArrayList<String> second_item = new ArrayList<String>();
			//Run over all the users that viewed title2
			for (User u : getUsersByItem(title2)) {
				//add their username to the second item array
				second_item.add(u.getUsername());
			}
			
			
			//Check if for one of the items there is no history view
			if (first_item.size() == 0 && second_item.size() == 0) {
				System.out.println("At least one of the movies has no history view");
				return 0;
			}
			
			//We initialise an array with the usernames that related to history view of title1
			ArrayList<String> intersections = new ArrayList<String>(first_item);
			//ratainAll modify the list such that it retains only the elements that are also present in the second item array
			intersections.retainAll(second_item);
			
			//get the size 
			double intersection = intersections.size();
			double union = Math.abs(first_item.size() + second_item.size() - intersection);
	
			result = (intersection / union);
	    }
	    catch (Exception e) {
	        e.printStackTrace();

	    } finally {
	        if (mongoClient != null)
	            mongoClient.close();
	        }
		return result;
	}
	

}
