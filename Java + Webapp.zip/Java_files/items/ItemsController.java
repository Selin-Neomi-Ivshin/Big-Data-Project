/**
 * 
 */
package org.bgu.ise.ddb.items;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.MediaItems;
import org.bgu.ise.ddb.ParentController;
import org.bson.Document;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;



/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/items")
public class ItemsController extends ParentController {
	
	
	
	/**
	 * The function copy all the items(title and production year) from the Oracle table MediaItems to the System storage.
	 * The Oracle table and data should be used from the previous assignment
	 */
	@RequestMapping(value = "fill_media_items", method={RequestMethod.GET})
	public void fillMediaItems(HttpServletResponse response){
		System.out.println("was here");
		//:TODO your implementation
		
		//Initialise variables
		Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        HttpStatus status = null;
        MongoClient mongoClient = null;

        
        try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Create a connection to the MS SQL database
            conn = DriverManager.getConnection("jdbc:sqlserver://132.72.64.124:1433;databaseName=" + "ivshins" + ";user=" + "ivshins" + ";" +
                    "password=" + "qivT|9X=" + ";encrypt=false;");
            
            //Select from MS SQL the title and the prod_year columns
            ps = conn.prepareStatement("SELECT TITLE , PROD_YEAR FROM MediaItems");
            //execute the query
            rs = ps.executeQuery();

            // While there are still items in the MediaItems table
            while (rs.next()) {
            	
            	//extract the title and the year in each iteration
                String title = rs.getString("TITLE");
                int Prod_Year = rs.getInt("PROD_YEAR");
                
                //Connect to Mongo DB
                mongoClient = new MongoClient("localhost", 27017);
                // Get the MongoDB database
                DB db = mongoClient.getDB("BigDataProject");
                // Get the collection that holds the items
                DBCollection collection = db.getCollection("Items");
                // Create a query to check if the item exists by title
                BasicDBObject query = new BasicDBObject("title", title);
                // Execute the query and check if any document matches the query
                boolean exists = collection.count(query) > 0;
 
                
                //Check if the item doesn't exist in Mongo DB and add it 
                if (!exists) {
                	BasicDBObject item1 = new BasicDBObject();
    			    item1.put("title", title);
    			    item1.put("prod_year", Prod_Year);
    			 // Insert the item to the MongoDB collection
                    collection.insert(item1);
                 // Close the MongoDB connection
                    mongoClient.close();
				}
                
                else {
                	// Close the MongoDB connection
                	mongoClient.close();
                }
            }
            rs.close();
            conn.close();
            status = HttpStatus.OK;
            
        } catch (Exception e) {
            System.out.println(e);
            status = HttpStatus.CONFLICT;
            
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (ps != null)
                    ps.close();
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            response.setStatus(status.value());
        }
    }
	
	

	/**
	 * The function copy all the items from the remote file,
	 * the remote file have the same structure as the films file from the previous assignment.
	 * You can assume that the address protocol is http
	 * @throws IOException 
	 */
	@RequestMapping(value = "fill_media_items_from_url", method={RequestMethod.GET})
	public void fillMediaItemsFromUrl(@RequestParam("url")    String urladdress,
			HttpServletResponse response) throws IOException{
		System.out.println(urladdress);
		
		//:TODO your implementation

		HttpStatus status = null;
		URL url = null;
		BufferedReader br = null;
		MongoClient mongoClient = null;

		//Create a new URL object using the urladdress to represent the remote file's address
		url = new URL(urladdress);
		//https://drive.google.com/uc?export=download&id=1nu33_hB7kB38g75XeCQMqnzpBqFb4t40
		//Initialise an empty string for storing each line of the file as it is read.
		String line = "";

		try {
			//Establishing a connection to the remote file 
		    URLConnection urlConn = url.openConnection();
		    //Reading line by line the contents of the remote file
		    br = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));	
		    
		    //While there is still what to read in the file
			while ((line = br.readLine()) != null) {
				//split the line string into an array of substrings, the first sub - title, second - prod_year
				String[] column = line.split(",");
				//creating variable for holding the prod_year
				int Prod_Year = Integer.parseInt(column[1]);
				
				
				//Connect to Mongo DB
                mongoClient = new MongoClient("localhost", 27017);
                // Get the MongoDB database
                DB db = mongoClient.getDB("BigDataProject");
                // Get the collection that holds the items
                DBCollection collection = db.getCollection("Items");
                // Create a query to check if the item exists by title
                BasicDBObject query = new BasicDBObject("title", column[0]);
                // Execute the query and check if any document matches the query
                boolean exists = collection.count(query) > 0;
 
                
                //Check if the item doesn't exist in Mongo DB and add it 
                if (!exists) {
                	BasicDBObject item1 = new BasicDBObject();
    			    item1.put("title", column[0]);
    			    item1.put("prod_year", Prod_Year);
    			 // Insert the item to the MongoDB collection
                    collection.insert(item1);
                    // Close the MongoDB connection
                    mongoClient.close();
				}
                
                else {
                    // Close the MongoDB connection
                	mongoClient.close();
                }
		}
			

			status = HttpStatus.OK;
		} catch (Exception e) {
			e.printStackTrace();
			status = HttpStatus.CONFLICT;
		} finally {
			response.setStatus(status.value());
		}
	}
	
	
	/**
	 * The function retrieves from the system storage N items,
	 * order is not important( any N items) 
	 * @param topN - how many items to retrieve
	 * @return
	 */
	@RequestMapping(value = "get_topn_items",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(MediaItems.class)
	public  MediaItems[] getTopNItems(@RequestParam("topn")    int topN){
		//:TODO your implementation
//		MediaItems m = new MediaItems("Game of Thrones", 2011);
//		System.out.println(m);
//		return new MediaItems[]{m};
		
		//Initialise variables
		MongoClient mongoClient = null;
		ArrayList<MediaItems> N_items = new ArrayList<MediaItems>();

 
		    try {
		        // Create a connection and a cursor over the Users collection
		        mongoClient = new MongoClient("localhost", 27017);
		        DB db = mongoClient.getDB("BigDataProject");
		        DBCollection collection = db.getCollection("Items");
		        //find() retrieves all documents in the collection by limiting the number to topN
		        if (topN > 0) {
		        DBCursor cursor = collection.find().limit(topN);

		        // Map documents within the collection to Users objects
		        try {
		        	//while there is still a document
		            while (cursor.hasNext()) {
		            	// retrieving the next document from the cursor and put it in doc
		                DBObject doc = cursor.next();
		                //Creating a new MediaItems object using values from the doc document.
		                //Constructing a new MediaItems object, which is added to the N_items list.
		                N_items.add(new MediaItems(doc.get("title").toString(), (int) doc.get("prod_year")));


		            }
		            

		        } 
		        finally {
		            cursor.close();
		        }

		    }
		        } catch (Exception e) {
		        System.out.println(e);
		    } finally {
		        if (mongoClient != null)
		            mongoClient.close();
		    }
		    return N_items.toArray(new MediaItems[N_items.size()]);
		}
}
		


