/**
 * 
 */
package org.bgu.ise.ddb.registration;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.ParentController;
import org.bgu.ise.ddb.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.mongodb.*;
import java.util.ArrayList;
import java.util.List;
/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/registration")
public class RegistarationController extends ParentController{
	
	
	/**
	 * The function checks if the username exist,
	 * in case of positive answer HttpStatus in HttpServletResponse should be set to HttpStatus.CONFLICT,
	 * else insert the user to the system  and set to HttpStatus in HttpServletResponse HttpStatus.OK
	 * @param username
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param response
	 */
	@RequestMapping(value = "register_new_customer", method={RequestMethod.POST})
	public void registerNewUser(@RequestParam("username") String username,
			@RequestParam("password")    String password,
			@RequestParam("firstName")   String firstName,
			@RequestParam("lastName")  String lastName,
			HttpServletResponse response){
		System.out.println(username+" "+password+" "+lastName+" "+firstName);
		//:TODO your implementation

		
		//Initialise Variable
		HttpStatus status = null;
		MongoClient mongoClient = null;
		DBCollection users = null;
		try {
			if (isExistUser(username)) {
				// Update status in case the username is taken
				status = HttpStatus.CONFLICT;

			}
			else {
				// Create a connection and get the Users collection
				mongoClient = new MongoClient("localhost", 27017);
				DB db = mongoClient.getDB("BigDataProject");
				users = db.getCollection("Users"); // get Users collection

				// Create new user document and insert it to the DB
				BasicDBObject newUser = new BasicDBObject();
			    newUser.put("username", username);
			    newUser.put("password", password);
			    newUser.put("firstName", firstName);
			    newUser.put("lastName", lastName);
			    newUser.put("registrationDate", LocalDate.now().toString());

			    // Insert the document into the collection
			    users.insert(newUser);

	            // Set HttpStatus to OK
	            status = HttpStatus.OK;

			}
		}
		catch (IOException e) {
			e.printStackTrace();
		} 
		finally {
			if (mongoClient != null)
				mongoClient.close();
			response.setStatus(status.value());
		}
		
	}
	
	/**
	 * The function returns true if the received username exist in the system otherwise false
	 * @param username
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "is_exist_user", method={RequestMethod.GET})
	public boolean isExistUser(@RequestParam("username") String username) throws IOException{
		System.out.println(username);
		boolean result = false;
		//:TODO your implementation
		
		//initialise variables
		MongoClient mongoClient = null;
		
		 try {
	            // Connect to MongoDB and get the Users collection
	            mongoClient = new MongoClient("localhost", 27017);
	            DB db = mongoClient.getDB("BigDataProject");
	            DBCollection users = db.getCollection("Users");

	            // Create query
	            BasicDBObject query = new BasicDBObject();
	            query.put("username", username);

	            // Execute query
	            DBCursor cursor = users.find(query);

	            // Check if any result found
	            if (cursor.count() > 0) {
	                result = true;
	            }

	            // Close connection
	            mongoClient.close();
	        } catch (MongoException e) {
	            e.printStackTrace();
	        }
		 	catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (mongoClient != null) {
					mongoClient.close();
				}
			}
	        return result;
			}
		
	

	
	/**
	 * The function returns true if the received username and password match a system storage entry, otherwise false
	 * @param username
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "validate_user", method = RequestMethod.POST)
	public boolean validateUser(@RequestParam("username") String username,
			@RequestParam("password")    String password) throws IOException{
		System.out.println(username+" "+password);
		boolean result = false;
		//:TODO your implementation
		
		//initialise variables
		MongoClient mongoClient = null;
		
		try {
			//connect to MongoDB
			mongoClient = new MongoClient("localhost", 27017);
			DB db = mongoClient.getDB("BigDataProject");
			DBCollection users = db.getCollection("Users"); // get Users collection
			BasicDBObject myQuery = new BasicDBObject();
			myQuery.put("username", username);
			myQuery.put("password", password);
			DBCursor cursor = users.find(myQuery);//Send query to Mongo, get the results

		
		//check if we find at least one result
		if (cursor.count() != 0) {
			result = true;
		}
		mongoClient.close();
		
	}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (mongoClient != null)
				mongoClient.close();
		}
		return result;
		
	}
	
	/**
	 * The function retrieves number of the registered users in the past n days
	 * @param days
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "get_number_of_registred_users", method={RequestMethod.GET})
	public int getNumberOfRegistredUsers(@RequestParam("days") int days) throws IOException{
		System.out.println(days+"");
		int result = 0;
		//:TODO your implementation
		
		//initialise variables
	    MongoClient mongoClient = null;
	    
	    //if the past n days is negative we will throw an exception
	    if (days < 0) {
	    	throw new IllegalArgumentException ("There is no such negative days");
	    }
	    
	    try {
	        // Connect to MongoDB and get the Users collection
	        mongoClient = new MongoClient("localhost", 27017);
	        DB db = mongoClient.getDB("BigDataProject");
	        DBCollection users = db.getCollection("Users");

	        // Calculate the date n days ago:
	        //Get the current date
	        LocalDate currentDate = LocalDate.now();
	        //subtract the specified number of days from the current date and save it in pastDate
	        LocalDate pastDate = currentDate.minusDays(days);

	        // Create the query to count the registered users within the past n days
	        BasicDBObject query = new BasicDBObject();
	        //gte compares the values in registrationDate and selects documents where 
	        //the value of the field is greater than or equal to the specified value.
	        query.put("registrationDate", new BasicDBObject("$gte", pastDate));

	        // Execute the query and get the count
	        result = users.find(query).count();
	        
	    } catch (MongoException e) {
	        e.printStackTrace();
	    } finally {
	        if (mongoClient != null)
	            mongoClient.close();
	    }

		return result;
		
	}
	
	/**
	 * The function retrieves all the users
	 * @return
	 */
	@RequestMapping(value = "get_all_users",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(User.class)
	public  User[] getAllUsers(){
		//:TODO your implementation
		
		 //Initiate variables
		 MongoClient mongoClient = null;
		 
		    try {
		        // Connect to MongoDB and get the Users collection
		        mongoClient = new MongoClient("localhost", 27017);
		        DB db = mongoClient.getDB("BigDataProject");
		        DBCollection users = db.getCollection("Users");

		        // Fetch all users from the collection
		        DBCursor cursor = users.find();
		        
		        //create an empty list of users
		        List<User> usersList = new ArrayList<>();

		        // Iterate over the cursor and convert documents to User objects
		        try{
		        	while (cursor.hasNext()) {
		        
		            DBObject doc = cursor.next();
		            String username = (String) doc.get("username");
		            String password = (String) doc.get("password");
		            String firstName = (String) doc.get("firstName");
		            String lastName = (String) doc.get("lastName");

		            User user = new User(username, password, firstName, lastName);
		            
		            //add the user to the list
		            usersList.add(user);
		        }
		      }
		        //close cursor
		        finally {
		        	cursor.close();
		        }
		        
		        
		        System.out.println(usersList);
		        
		        // creating new array of User objects with the same size as the ArrayList and return it
		        return usersList.toArray(new User[usersList.size()]);
		        
		    } catch (Exception e) {
				e.printStackTrace();

		    } finally {
		        if (mongoClient != null) {
		            mongoClient.close();
		        }
		    }
		    
		    //if there is no users list, return null
			return null;
	}

}
